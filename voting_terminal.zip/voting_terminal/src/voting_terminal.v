module voting_terminal (
    input wire clk,
    input wire reset,
    input wire [3:0] buttons,
    output reg [6:0] seg,
    output reg [3:0] an,
    output reg [3:0] led
);

    reg [3:0] previous_buttons;
    reg [3:0] vote_count [0:3];
    reg [1:0] selected;
    reg [3:0] display_value;

    integer i;

    // Detect a new button press
    always @(posedge clk) begin
        if (reset) begin
            previous_buttons <= 4'b0000;
            selected <= 2'b00;
            led <= 4'b0000;

            for (i = 0; i < 4; i = i + 1)
                vote_count[i] <= 4'b0000;
        end
        else begin
            previous_buttons <= buttons;

            // Buttons 0-2 select candidates.
            // Button 3 records a vote.
            if (buttons[0] && !previous_buttons[0])
                selected <= 2'd0;

            else if (buttons[1] && !previous_buttons[1])
                selected <= 2'd1;

            else if (buttons[2] && !previous_buttons[2])
                selected <= 2'd2;

            else if (buttons[3] && !previous_buttons[3]) begin
                if (vote_count[selected] < 4'd9)
                    vote_count[selected] <=
                        vote_count[selected] + 1'b1;
            end

            led <= 4'b0001 << selected;
        end
    end

    // Display the selected candidate's vote count
    always @(*) begin
        an = 4'b1110;

        case (vote_count[selected])
            4'd0: display_value = 4'd0;
            4'd1: display_value = 4'd1;
            4'd2: display_value = 4'd2;
            4'd3: display_value = 4'd3;
            4'd4: display_value = 4'd4;
            4'd5: display_value = 4'd5;
            4'd6: display_value = 4'd6;
            4'd7: display_value = 4'd7;
            4'd8: display_value = 4'd8;
            4'd9: display_value = 4'd9;
            default: display_value = 4'd0;
        endcase

        // Seven-segment decoder (active-low segments)
        case (display_value)
            4'd0: seg = 7'b1000000;
            4'd1: seg = 7'b1111001;
            4'd2: seg = 7'b0100100;
            4'd3: seg = 7'b0110000;
            4'd4: seg = 7'b0011001;
            4'd5: seg = 7'b0010010;
            4'd6: seg = 7'b0000010;
            4'd7: seg = 7'b1111000;
            4'd8: seg = 7'b0000000;
            4'd9: seg = 7'b0010000;
            default: seg = 7'b1111111;
        endcase
    end

endmodule
