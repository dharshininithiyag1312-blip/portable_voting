# voting_terminal

Simple 3-candidate voting terminal in Verilog, targeted at the Digilent Basys 3.

## Layout
- src/voting_terminal.v      design
- sim/tb_voting_terminal.v   self-checking testbench
- constraints/basys3.xdc     pin constraints (adjust for other boards)

## Controls (Basys 3)
- BTNU / BTNL / BTNR : select candidate 0 / 1 / 2
- BTND               : cast a vote for the selected candidate (max 9)
- BTNC               : reset
- LD0-LD2 show the selected candidate; the rightmost digit shows its vote count

## Simulate (Icarus Verilog)
    iverilog -o sim.out src/voting_terminal.v sim/tb_voting_terminal.v
    vvp sim.out

## Notes
- Buttons are not debounced or synchronized. On real hardware add a
  synchronizer + debouncer, or contact bounce at 100 MHz will register
  as multiple presses.
- Candidate 3 (selected == 3) is unreachable with the current button mapping.
