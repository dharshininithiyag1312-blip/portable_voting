`timescale 1ns/1ps
module tb_voting_terminal;
    reg clk = 0, reset = 1;
    reg [3:0] buttons = 4'b0000;
    wire [6:0] seg;
    wire [3:0] an, led;
    integer errors = 0;

    voting_terminal dut (.clk(clk), .reset(reset), .buttons(buttons),
                         .seg(seg), .an(an), .led(led));

    always #5 clk = ~clk;

    task press(input [3:0] b);
        begin
            buttons = b; @(posedge clk); @(posedge clk);
            buttons = 4'b0000; @(posedge clk); @(posedge clk);
        end
    endtask

    task check(input [3:0] exp_count, input [1:0] exp_sel);
        begin
            if (dut.vote_count[exp_sel] !== exp_count || dut.selected !== exp_sel) begin
                $display("FAIL: sel=%0d count=%0d (expected sel=%0d count=%0d)",
                         dut.selected, dut.vote_count[exp_sel], exp_sel, exp_count);
                errors = errors + 1;
            end
        end
    endtask

    integer k;
    initial begin
        $dumpfile("tb_voting_terminal.vcd");
        $dumpvars(0, tb_voting_terminal);
        repeat (3) @(posedge clk);
        reset = 0;

        press(4'b0001);                 // select candidate 0
        press(4'b1000); press(4'b1000); // 2 votes
        check(4'd2, 2'd0);

        press(4'b0010);                 // select candidate 1
        press(4'b1000);
        check(4'd1, 2'd1);

        press(4'b0100);                 // select candidate 2
        for (k = 0; k < 12; k = k + 1) press(4'b1000); // saturates at 9
        check(4'd9, 2'd2);

        // Holding the vote button counts only once
        press(4'b0001);
        buttons = 4'b1000; repeat (10) @(posedge clk); buttons = 0; @(posedge clk);
        check(4'd3, 2'd0);

        reset = 1; @(posedge clk); @(posedge clk); reset = 0;
        check(4'd0, 2'd0);

        if (errors == 0) $display("ALL TESTS PASSED");
        else $display("%0d TEST(S) FAILED", errors);
        $finish;
    end
endmodule
